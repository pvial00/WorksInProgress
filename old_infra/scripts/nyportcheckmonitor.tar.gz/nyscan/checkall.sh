#!/bin/bash
cd /home/kzander/nyscan
> report.txt
files=`ls *.out`

for x in $files
do
	host=`grep "report for" $x | cut -d ' ' -f 5`
	if ping -c 1 $host; then
		echo "host $host is up" >> report.txt
	else
		echo "host $host is down" >> report.txt
	fi
	ports=`grep tcp $x | cut -d '/' -f 1`
	for i in $ports
	do
		if nc -w 1 $host $i; then
			echo "host $host port $i is up" >> report.txt
		else
			echo "host $host port $i is down" >> report.txt
		fi
	done
done
mail -s "NY host health check" nagios-alert@boinc.com < report.txt
