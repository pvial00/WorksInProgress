#!/bin/bash
while read line
do
	sudo nmap -Pn -p 1-65535 $line > $line.out
done<hosts
